# 游戏强化学习转岗：权威资料核实与短期实践建议

核实日期：2026-09-22。面向：游戏客户端工程师，已会 Python 和基础机器学习，集中投入 1–2 周。本文供汇总教材使用，优先级是针对所给 JD 的学习建议，并非统计意义上的面试出现频率。

P0＝这两周应能解释并动手；P1＝应能比较原理、读懂方案；P2＝了解用途与局限，后续按实际团队方向深入。

## 1. 已核实的一手资料与精读范围

### 基础、书籍与课程

| 优先级 | 来源／类型／链接 | 推荐阅读范围 | 应能回答的问题／核实备注 |
|---|---|---|---|
| P0 | Sutton & Barto, *Reinforcement Learning: An Introduction*, 2e／作者书籍页：[作者入口](http://incompleteideas.net/book/the-book-2nd.html)；[Stanford CS234 官方引用与 final PDF 入口](https://web.stanford.edu/class/cs234/) | 第 3 章 MDP；第 4 章 DP 的策略评估、策略迭代、价值迭代；第 5–6 章 MC、TD、SARSA、Q-learning；第 13 章策略梯度。第 2 章多臂老虎机和第 7 章 n-step 作为补充 | 以 Bellman、bootstrap、on/off-policy、策略梯度为主线。作者站本次 direct fetch 超时／502，**已由 CS234 官方课程页验证书名与免费作者入口，但未声称本次读通整本 PDF**。不要拿 2016 in-progress 草稿当最终版；书中没有现代 PPO 完整工程教程。 |
| P0 | Stanford CS234 Winter 2026／大学官方课程：[课程页](https://web.stanford.edu/class/cs234/) | Tabular MDP Planning、Policy Evaluation、Q-learning and function approximation、Policy Search；再选 Imitation Learning、Offline RL | 先修条件正好是 Python、微积分／线代、概率统计与 ML。可以用课程学习目标自测：给业务建 MDP、说明算法选择、实现并比较样本／计算效率。课程 2026 也含 RLHF，但不意味着游戏岗位只考 LLM。 |
| P0/P1 | UC Berkeley CS185/285 Spring 2026／大学官方课程：[当前课程](https://rll.berkeley.edu/deeprlcourse/)；[大学目录](https://www2.eecs.berkeley.edu/Courses/CS285/) | Lecture 2–3 BC、4 RL Basics、5 PG、6 Actor Critic、7 Value-Based RL、8 Q-learning in Practice、9–10 Advanced PG；有余力看 Lecture 14 LLM RL | 学习顺序可由 BC 开始，再 PG/AC、Q-learning；不要两周通刷全学期。主页本次解析正文为空，但搜索索引能读取 2026 排课，大学课程目录独立确认核心内容；视频历史版本年份与当前课程年份需区分。 |
| P0 | Spinning Up／OpenAI 教学文档：[总入口](https://spinningup.openai.com/en/latest/)；[算法目录](https://spinningup.openai.com/en/latest/user/algorithms.html) | RL Intro；PPO 与 SAC 的 key equations、pseudocode；核心 buffer 逻辑 | 适合补算法直觉与伪代码。其代码与安装文档仍涉及 OpenAI Gym、TensorFlow v1、MPI；**理论资料可读，旧安装命令不作为 2026 新项目基线**。别把原文的历史 SOTA 表述写成当前 SOTA。 |
| P0 查缺补漏 | Goodfellow/Bengio/Courville, *Deep Learning*／作者官网：[在线书](https://www.deeplearningbook.org/) | 第 2–4 章按需补线代／概率／数值稳定；第 6–8 章 MLP、反传、正则化、优化；第 11 章实验方法 | 解释梯度消失／爆炸、过拟合、训练验证划分、初始化与优化器。官网免费 HTML 正文已核实；不推荐来路不明的整本 PDF。 |
| P0 查缺补漏 | Stanford CS229／讲义原文：[2026 官方讲义](https://cs229.stanford.edu/main_notes.pdf) | Logistic regression；backprop；bias-variance；regularization/model selection。LLM/Transformer 只做后续选读 | 本次打开为 2026-08-23 版 278 页 PDF；基础薄弱处按章节补，不要为了游戏 RL 转岗重读所有传统 ML。 |

### 核心算法原论文

| 优先级 | 一手来源 | 阅读范围 | 必须抓住的点 |
|---|---|---|---|
| P0 | [DQN, Playing Atari with Deep RL, 2013](https://arxiv.org/abs/1312.5602)；[2015 Nature 正式论文入口](https://www.nature.com/articles/nature14236) | Q-learning 目标、replay、网络输入输出、训练流程 | DQN 是 value-based/off-policy，输出各离散动作 Q 值。2013 workshop 与 2015 Nature 版要区分；2015 页本次受站点授权重定向影响未成功取全文。实现 target network 等细节用当前官方教程／实现交叉检查。 |
| P0 | [Double DQN, 2015/AAAI 2016](https://arxiv.org/abs/1509.06461) | 方法和目标公式 | 用 online Q 选动作、target Q 估值以缓解最大化导致的高估；不要说普通 DQN 有两套网络就等于 Double DQN。 |
| P0 | [GAE, 2015/2016](https://arxiv.org/abs/1506.02438) | Advantage、TD residual、λ 加权估计 | 降低策略梯度估计方差，以价值估计偏差为代价；明确 γ 与 λ 不是同一个参数。 |
| P0 | [PPO, 2017](https://arxiv.org/abs/1707.06347)；[Spinning Up PPO](https://spinningup.openai.com/en/latest/algorithms/ppo.html) | clipped objective、伪代码、与 TRPO 的关系 | 比值新策略／旧策略；min 对正负 advantage 的行为；PPO-Clip 不提供严格 KL 上界；同一轮 rollout 可做有限次 minibatch 更新，但不能随意混很旧 replay。 |
| P1 | [SAC, 2018 原版](https://arxiv.org/abs/1801.01290)；[SAC Algorithms and Applications, 2018 后续版](https://arxiv.org/abs/1812.05905)；[Spinning Up SAC](https://spinningup.openai.com/en/latest/algorithms/sac.html) | max-entropy 目标、双 Q、actor 更新、温度 α、重参数化 | off-policy，经验复用；常见版本用于连续控制。2018 原版含显式 V 网络，常用后续版本可不用单独 V；不要把两版公式混写。连续 tanh policy 的 log-prob 要含 Jacobian 修正。 |
| P0/P1 | [DAgger, 2010/2011](https://arxiv.org/abs/1011.0686) | 方法动机、数据聚合流程；配合 CS285 BC 讲义 | BC 在专家状态分布监督学习，部署后会进入自己的状态分布而误差累积；DAgger 让当前策略采样，再向专家查询动作并聚合训练集。它需要可查询专家，不是无成本离线技巧。 |
| P1 | [MAPPO, 2021/2022](https://arxiv.org/abs/2103.01955) | central critic、PPO 配置与消融 | 合作多智能体可用 CTDE：训练 critic 见更多全局信息，部署 actor 仅用可获得局部观察。策略共享与否、死亡 masking、数据复用量、value normalization 都可能影响效果；MAPPO 不是所有游戏的通用最优解。 |
| P1 | [QMIX, 2018](https://arxiv.org/abs/1803.11485) | mixing network 与单调约束 | 约束 ∂Q_tot/∂Q_i ≥ 0，从而协调 joint greedy 与 local greedy；适用于合作任务的价值分解。它的表达能力有约束，不是任意联合价值函数都可表达。 |
| P0 工程 | [Invalid Action Masking, 2020](https://arxiv.org/abs/2006.14171) | 动作掩码的策略梯度解释和实验 | 游戏冷却、距离、资源不足等无效动作可屏蔽；采样、log-prob、训练、评估要使用一致 mask；确保至少一个有效动作；不能把不可见信息偷偷编码进 mask。 |

### 游戏案例：用来解释系统设计，不要求复现规模

| 优先级 | 一手来源 | 精读范围 | 面试可迁移点 |
|---|---|---|---|
| P1 | [OpenAI Five 论文，Dota 2 with Large Scale Deep RL, 2019](https://arxiv.org/abs/1912.06680)；[作者 PDF](https://cdn.openai.com/dota-2.pdf) | 系统图、PPO/self-play、观察动作设计、工程与消融 | 长时程、部分可观测、团队奖励、算力／样本吞吐、训练版本持续更新。别把论文的特定游戏设置直接说成完整无约束 Dota 2。 |
| P1 | [AlphaStar Final 官方介绍，2019-10-30](https://deepmind.google/blog/alphastar-grandmaster-level-in-starcraft-ii-using-multi-agent-reinforcement-learning/) | 模仿预训练、league、相机／动作约束、评估 | 模仿学习冷启动＋多样对手训练；只与最新自己对战可能产生循环克制与遗忘。必须区分 2019-01 展示版和 2019-10 Final 条件。 |
| P2 | [Towards Playing Full MOBA Games with Deep RL, 2020](https://arxiv.org/abs/2011.12692) | 业务问题拆分、复杂动作控制、训练与评测系统 | 国内游戏业务对应度较高；只读方法图和实验，不把大规模系统复现当两周目标。 |

### 当前工程接口与框架

| 优先级 | 官方资料 | 推荐范围 | 核实结论与版本陷阱 |
|---|---|---|---|
| P0 | [Gymnasium time limits](https://gymnasium.farama.org/tutorials/gymnasium_basics/handling_time_limits/) | 全文，短文必读 | `step` 返回 obs,reward,terminated,truncated,info；`reset` 返回 obs,info。真实任务终止一般不 bootstrap；外部截断通常 bootstrap；有内生时间上限的 finite-horizon MDP 可能属于 termination，且剩余时间要进状态。 |
| P0 | [SB3 custom env](https://stable-baselines3.readthedocs.io/en/master/guide/custom_env.html)；[RL tips](https://stable-baselines3.readthedocs.io/en/master/guide/rl_tips.html) | `check_env`、空间兼容、评估、normalization、multiple seeds | 用成熟实现先建可跑基线；SB3 只支持 Gymnasium 的部分空间功能。master 本次为 2.9.2a0 开发文档，实操要固定安装版本并切换匹配文档；别把 master 页版本当稳定版。 |
| P0 | [CleanRL](https://docs.cleanrl.dev/)；[PPO 详解](https://docs.cleanrl.dev/rl-algorithms/ppo/) | PPO 单文件实现与 implementation details | 适合逐行理解 rollout→GAE→minibatch→loss→optimizer；看 entropy、clip fraction、approx KL、explained variance、SPS。不要仅跑完命令就自称实现 PPO。 |
| P0 | [PyTorch autograd](https://docs.pytorch.org/tutorials/beginner/basics/autogradqs_tutorial.html)；[optimization](https://docs.pytorch.org/tutorials/beginner/basics/optimization_tutorial.html) | requires_grad、动态图、detach/no_grad、训练循环 | 能写零梯度→forward→loss→backward→step；解释 `model.eval()` 与禁止梯度的区别；RL 中 old log-prob、bootstrap targets、advantage 应正确脱离 actor 梯度。 |
| P1 | [PyTorch DDP 官方教程](https://docs.pytorch.org/tutorials/intermediate/ddp_tutorial.html) | 进程初始化、梯度同步、数据分片、checkpoint | DDP 是多个进程的数据并行梯度同步，不等于向量环境，也不等于异步 actor-learner。先能画出这三种并行解决的不同瓶颈。 |
| P1；JD明确点名 | [RLlib key concepts](https://docs.ray.io/en/latest/rllib/key-concepts.html)；[AlgorithmConfig](https://docs.ray.io/en/latest/rllib/algorithm-config.html)；[scaling guide](https://docs.ray.io/en/latest/rllib/scaling-guide.html) | EnvRunner、RLModule、Learner、ConnectorV2、Episode；采样／训练扩展轴 | latest 本次显示 Ray 2.58.0；核心配置是 `.env_runners(num_env_runners=...)`、`.env_runners(num_envs_per_env_runner=...)`、`.learners(num_learners=...)`。分别扩采样 actor、单 actor 多环境、更新 learner；三者不能混称多 GPU 训练。 |
| P1 | [RLlib 新栈迁移指南](https://docs.ray.io/en/master/rllib/new-api-stack-migration-guide.html)；[getting started](https://docs.ray.io/en/master/rllib/getting-started.html) | 新旧栈映射、PPOConfig、build_algo、checkpoint/inference | master 本次为 3.0.0.dev0 开发文档；latest 的部分页直读遭 429，当前 latest key-concepts 和 config／scaling 搜索索引成功核实。新栈以 PyTorch 为当前支持框架；学习时不要混用 `ModelV2`/`RolloutWorker` 旧例和 `RLModule`/`Learner` 新例。安装请锁 release 并对照对应版本，本文不提供未经运行的“保证可用”安装矩阵。 |
| P1 客户端方向 | [Unity ML-Agents 当前官方文档入口](https://docs.unity3d.com/Packages/com.unity.ml-agents@latest/)；[4.1 文档](https://docs.unity3d.com/Packages/com.unity.ml-agents@4.1/manual/index.html) | Agent 生命周期、观测、动作、奖励、训练配置、Inference Engine；自博弈作为扩展 | 当前 latest 的跳转内容指向 4.1；原 [github.io 站](https://unity-technologies.github.io/ml-agents/) 明确“deprecated and no longer maintained”。先匹配 Unity package、Python package、引擎版本，再看当前手册。不要照搬旧 Barracuda／旧 Brain 教程。 |
| P1 客户端方向 | [ONNX Runtime C++](https://onnxruntime.ai/docs/get-started/with-cpp.html) | 模型载入、tensor 输入输出、执行提供程序 | 可把 PyTorch policy 导出后接入客户端，重点验证 feature 顺序、dtype、归一化、mask 和 Python 输出一致；C++ SDK 运行时、线程／内存、推理延迟比模型文件大小更值得展示。实际 exporter/API 以安装版 PyTorch 文档为准。 |

## 2. 核心公式与容易说错的地方

本节是学习自查，不是面经频次结论。采用 `r_t` 表示执行 `a_t` 后收到的奖励，避免与书中 `R_{t+1}` 记号混淆。来源为上述 Sutton/Barto、PPO、GAE、Double DQN、SAC 与 Gymnasium 官方资料。

1. **MDP 与 Bellman**

   `G_t = Σ_{k≥0} γ^k r_{t+k}`；`V^π(s) = E_π[G_t | s_t=s]`；`Q^π(s,a)=E[r_t+γV^π(s_{t+1}) | s_t=s,a_t=a]`；`A^π(s,a)=Q^π(s,a)-V^π(s)`。

   策略评估对 action 按 π 求期望；最优 Bellman 方程对 action 取 max。部分可观测游戏中 `o_t` 通常不是 Markov state，需要历史、RNN／记忆、belief 或更充分状态；不能假设服务端所有隐藏状态都能在玩家端推理使用。

2. **Q-learning／DQN 与 Double DQN**

   DQN: `y_t = r_t + γ(1-terminated_t) max_a Q_target(s_{t+1},a)`。

   Double DQN: `a*=argmax_a Q_online(s_{t+1},a)`，`y_t=r_t+γ(1-terminated_t)Q_target(s_{t+1},a*)`。

   用 `Huber(Q_online(s_t,a_t), stop_gradient(y_t))` 或 MSE；动作维 `gather` 正确；目标网络通常不反传；普通 DQN 的 target network 缓解移动目标，Double DQN 的“选择与估值分离”解决不同问题。离散动作 `argmax` 不能直接照搬到高维连续动作。

3. **策略梯度**

   `∇θJ ∝ E[∇θ log πθ(a_t|s_t) A^π(s_t,a_t)]`（比例/加权取决于折扣状态访问分布约定）。实现梯度下降时 actor loss 是负号：`L_actor = -mean(log_prob * advantage.detach())`。

   state-only baseline 不改变期望梯度，但能降方差；actor-critic 使用估计 advantage 会有估计误差，不要笼统说任何 critic 都无偏。区分采样轨迹的折扣目标与无折扣工程近似，避免背公式时省略所用期望的定义。

4. **GAE 与终止／截断**

   `δ_t = r_t + γ(1-terminated_t)V_old(s_{t+1}^{final}) - V_old(s_t)`。

   `Â_t = δ_t + γλ c_t Â_{t+1}`，其中 `c_t` 表示下一步 advantage 确实属于同一连续轨迹；reset 边界取 0。外部 time-limit truncation 通常保留本步 `V(final_obs)` bootstrap，但不能把 reset 后新 episode 的 advantage 串进来。rollout batch 结束需正确 bootstrap；向量环境 auto-reset 时用 final observation，不能错用下一局首帧。λ 接近 0 更像一步 TD，接近 1 更接近长轨迹估计；偏差／方差仍取决于 V 误差和截断方式。

5. **PPO-Clip**

   `ρ_t(θ)=exp(logπθ(a_t|s_t)-logπ_old(a_t|s_t))`。

   最大化 `E[min(ρ_t Â_t, clip(ρ_t,1-ε,1+ε) Â_t)]`；代码做最小化时取负。正 advantage 不再奖励把比率继续推得过高；负 advantage 不再奖励把比率继续压得过低。**不是所有概率变化都被硬限制在区间内**。old log-prob 在该轮 PPO epochs 固定；训练数据不能更新一次就重新算成“新 old policy”。总 loss 常含 value loss 与负 entropy bonus；记录 KL 与 clip fraction，检查 reward scaling、value clipping 等实现差异。

6. **SAC 的常用无独立 V 版本**

   `y=r+γ(1-terminated)[min_i Q_target,i(s',a')-α logπ(a'|s')]`，`a'~π`。

   actor 最小化 `E[αlogπ(a|s)-min_i Q_i(s,a)]`；目标 network、actor 中 Q 参数与 action 梯度路径要区分。tanh squash 的 log-density 必须做变量变换修正；对连续动作维求和获得联合 log-prob。α 控制 entropy 与 reward 的权衡，reward 尺度会影响相对强度；温度学习的符号与 target entropy 约定必须统一。

7. **BC／DAgger／Offline RL**

   离散 BC 最小化 `E_(o,a)~D[-logπ(a|o)]`；连续 BC 的 MSE 暗含特定似然与误差假设。BC 拟合动作不需要 reward，offline RL 用固定交互数据优化 return，后者额外面对 OOD action 的价值高估／外推。DAgger 要能为当前策略访问状态获取专家标注；把历史 replay 再混一遍不自动成为 DAgger。

8. **CTDE／QMIX**

   CTDE 是训练与执行的信息结构；不是一个算法。MAPPO 的 centralized critic 不应该造成 actor 部署时依赖不可得全局状态。QMIX 的 monotonic mixing 给 joint greedy 一致性施加条件，同时限制可表达的 value 类型。独立学习者看到的环境随其他 agent 更新而变化，不再是固定转移的普通单智能体场景。

9. **动作掩码**

   对 invalid logits 设很小值后重新归一化，并保证存在 valid action。计算 old/new log-prob 与 entropy 时保持相同 observation 对应 mask；训练、评估、导出推理一致。若 mask 来自未来信息、不可见敌人状态，即可能产生信息泄漏。

10. **评估与实验可信度**

   训练 reward 上升不等于策略更强；dense shaping 可以被利用。固定评估 seeds／对手池／地图版本，训练 seeds 至少多个；比较相同环境交互预算与 wall time；报告均值、离散程度、失败模式。训练集上的最优 checkpoint、随手挑的获胜视频、仅与当前自我对弈的 50% 胜率都不能单独证明泛化。小样本结果注明规模，不宣称统计显著。

## 3. 两周最小游戏 RL 作品建议（独立方案，不是文献承诺）

### 范围

做一个结构化观察的“小型 2D 闪避／追逐战斗场”，首版单学习者对固定脚本敌人，离散动作（停留／上下左右／技能），短回合，头部无渲染可跑，提供可视化回放。用户的客户端经验可体现在 fixed tick、reset/seed、动作冷却、技能合法性、通信与推理接口、性能剖析。若现成 Unity 工程与版本环境已可用，可以用 Unity ML-Agents；否则纯 Python Gymnasium 环境更适合 1–2 周的时间窗口。

**先完成** 环境→规则 baseline→成熟 PPO baseline→多 seed 评估→回放→解释失败原因。不要首周同时做视觉编码、大地图、多英雄、多智能体、分布式集群、LLM 控制器。

### 最小完成定义

- 环境接口：`reset(seed)` 可复现；observation/action spaces 匹配；termination/truncation 明确；环境 checker 通过；动作始终有合法 fallback。
- Baselines：random、合理的 rule-based、PPO；三者相同评估规则。规则策略还可产生 BC 数据，第二周可加 BC 对照。
- 指标：完成率／胜率、回合长度、受伤、非法动作数、环境 SPS、推理 p50/p95、固定评测配置。至少 3 个训练 seeds 与每 seed 100 回合是小作品的建议起点，非统计充分性保证；不足时如实报告。
- 两项有解释力的消融：例如“是否提供速度观察”“是否有 shaping／动作 mask”，每次只改一个因子。不要用过多调参消耗整周。
- 交付：README 中环境定义、算法选择、奖励设计与可能漏洞、复现命令和依赖锁定；学习曲线、指标表、失败录像；部署或导出一致性检查。

### 14 天建议

| 日 | 学习与实现 | 当天可核验产物 |
|---|---|---|
| 1 | 补 PyTorch autograd、MLP、训练循环；用小监督任务／BC 练手 | 能解释 shape、loss、detach、optimizer；训练曲线下降 |
| 2 | MDP、Bellman、MC/TD/SARSA/Q-learning | 手写 tabular Q-learning 小环境；口述 on/off-policy |
| 3 | DQN、target/replay、Double DQN | 用官方／成熟实现跑简单离散环境；画数据流 |
| 4 | PG、actor-critic、GAE | 手算一个 3 步轨迹并写 GAE，核对终止／截断 |
| 5 | PPO；逐行读 CleanRL | 写出 ratio、clip、value、entropy loss；解释日志 |
| 6 | 自定义 2D 环境与 random/rule baseline | 可复现 reset，checker，日志与回放 |
| 7 | SB3 PPO baseline 并记录失败 | 一个训练可跑配置＋基线表；若只有 7 天，至此整理作品与面试笔记 |
| 8 | 观察／奖励问题定位；跑第一个消融 | reward 漏洞／状态不足的证据 |
| 9 | 多 seed 与评估集 | 结果表，区分 train/eval；保留失败种子 |
| 10 | BC、DAgger 原理，脚本示范数据 | 选择性 BC baseline；说明何时需要专家查询 |
| 11 | Ray Core/RLlib 概念＋小规模并行采样 | 1 与 2/4 EnvRunners 的吞吐、wall time 对比；测不加速也解释开销 |
| 12 | SAC、CTDE/MAPPO/QMIX、自博弈 | 一页选型图：离散/连续，单/多智能体，对抗/合作，数据/算力成本 |
| 13 | C++ ONNX Runtime 或 Unity 模型接入（任选一项）；如果时间不足，优先导出与 Python 一致性验证 | 同批观察输出一致性、预处理契约、推理延迟；部署没完成要直说 |
| 14 | 整理 README、结果与 2 分钟演示；模拟项目深挖 | 能回答为什么选 PPO、坏在哪里、如何定位、下周如何改 |

### 该作品对 JD 的映射与诚实边界

- “对接游戏需求”：先说可玩性与业务指标，定义 bot 目的（陪练、自动测试、难度控制），而非默认追求最强胜率。
- “算法和框架／SDK”：展示环境协议、feature schema、策略推理接口、日志与可复现实验；这能使用原有客户端经验。
- “PyTorch／Ray”：说明真正跑过什么、遇到什么吞吐瓶颈。单机 4 个采样进程可以叫并行采样，不能包装成多机多 GPU 训练经验。
- “2 年相关经验／硕士”：两周作品不能补齐硬性学历或从业年限；可以形成岗位交流材料、验证兴趣并争取偏工程／游戏 AI 平台岗位。简历只写实测指标，不承诺两周转成成熟 RL 研究员。

## 4. 需要汇总者特别防止的过时与误导

1. 不把“任何算法岗必考”当事实：RL/game AI、推荐、CV、NLP、大模型应用的面试关注明显不同；本资料只根据 JD 给优先级。
2. 不混用 `Gym` 旧四元组 `done` 与 `Gymnasium` 新五元组，也别假设 SB3 VecEnv 与原生 Gymnasium VectorEnv 完全同 API。
3. 不复制 Spinning Up 的旧安装命令或环境版本字符串作为最新依赖方案。
4. 不混用 RLlib 旧栈与新栈；`latest` 与 `master` 本次已是不同版本。
5. Unity 当前 ML-Agents 文档已经迁移；旧页面底部“latest stable Release 22”不是当前包版本的可靠依据。
6. DQN／SAC 同名算法历史版本有差异；论文年份、现代实现、教学简化要分别说明。
7. PPO 不是保证单调改进；clip 不是严格 trust-region；“训练 reward 好看”不是成功证据。
8. “LLM Agent”中的 agent、RL agent、Agentic Coding 是不同含义。JD 明确要求编码工具能力，但不等于业务训练必须围绕大模型。
