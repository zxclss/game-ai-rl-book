
const topics=JSON.parse(document.getElementById('topic-data').textContent);
const input=document.getElementById('search');
const results=document.getElementById('results');
const toc=document.getElementById('toc');
const count=document.getElementById('count');
function search(){
 const query=input.value.trim().toLowerCase();results.replaceChildren();
 if(!query){toc.hidden=false;count.textContent=topics.length+' 个知识点 · 输入术语或编号检索';return;}
 toc.hidden=true;const words=query.split(/\s+/);
 const matches=topics.filter(t=>words.every(w=>(t.number+' '+t.title+' '+t.body).toLowerCase().includes(w)));
 count.textContent=matches.length+' 个匹配知识点';
 for(const topic of matches){
  const li=document.createElement('li'),a=document.createElement('a'),small=document.createElement('small');
  a.href='#k'+topic.number;a.textContent=topic.number+' · '+topic.title;
  small.textContent=topic.priority+' · '+topic.chapter;
  a.addEventListener('click',()=>{input.blur();});li.append(a,small);results.append(li);
 }
}
input.addEventListener('input',search);search();
document.getElementById('mobile-nav').addEventListener('click',()=>document.querySelector('aside').classList.toggle('expanded'));
document.getElementById('print-book').addEventListener('click',()=>window.print());
function progress(){const all=document.documentElement.scrollHeight-innerHeight;document.getElementById('progress-bar').style.width=(all>0?scrollY/all*100:0)+'%';}
addEventListener('scroll',progress,{passive:true});progress();
for(const el of document.querySelectorAll('[data-tex]')){
 try{
  if(!window.katex)throw new Error('本地 KaTeX 资源未加载');
  katex.render(el.dataset.tex,el,{displayMode:el.classList.contains('display'),throwOnError:true,trust:false});
 }catch(e){el.classList.add('math-fallback');el.title='公式排版失败：'+e.message;console.error(el.title,el.dataset.tex);}
}
const figureDialog=document.getElementById('figure-dialog');
for(const button of document.querySelectorAll('.figure-open')){
 button.addEventListener('click',()=>{
  const source=button.querySelector('img');
  document.getElementById('figure-large').src=button.dataset.full;
  document.getElementById('figure-large').alt=source.alt;
  document.getElementById('figure-original').href=button.dataset.full;
  document.getElementById('figure-title').textContent=source.alt;
  figureDialog.showModal();
 });
}
document.getElementById('figure-close').addEventListener('click',()=>figureDialog.close());
figureDialog.addEventListener('click',event=>{if(event.target===figureDialog)figureDialog.close();});
