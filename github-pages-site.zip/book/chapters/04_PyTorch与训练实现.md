# 第 4 章 PyTorch 与训练实现：让数学目标成为正确程序

本章代码是用于解释单个概念的教学片段，未声称已在你的机器运行；除完整展示导入的片段外，默认已 `import torch`，并按注释提供上下文对象。固定项目环境时，应记录 Python、PyTorch、设备与依赖版本，再阅读同版本官方文档。B 为 batch，T 为时间，N 为并行环境，D 为特征维，K 为动作数；竞技场基础动作 K=5。

## 知识点 031：完整训练步骤与数据契约

<!-- figure:f17:start -->
![训练形状、微批权重与广播](../assets/figures/f17.png)

**读图 · 训练形状、微批权重与广播**：左图先从输入到 logits 再到标量 loss，核对每一轴的意义、标签类型与平均维度；随后按清零、反传、更新执行，不能先反传再把梯度清掉。

*图中数值与轨迹为教学示意；中图柱宽表达 3:1 的样本数，右为 value=[[1],[3]] 减 target=[1,3]。*
<!-- figure:f17:end -->


**优先级：P0。** 训练不是一句 `loss.backward()`，而是一次有严格输入、状态和顺序约定的更新。输入需要匹配模型的设备与 dtype，目标需要与样本一一对应，梯度需要在正确时机清理，优化器还必须持有正在前向计算的那一组参数。任何环节错位，都可能表现为“模型不够好”。

对行为克隆，观测 x 为 `[B,D]` 浮点张量，专家动作 y 为 `[B]` 整数索引，模型输出 logits 为 `[B,K]`。目标是平均负对数似然 $L=-\frac1B\sum_i\log\pi_\theta(y_i\mid x_i)$。专家动作是固定监督信息，不应要求梯度；网络权重则是可训练参数。把 shape、dtype、设备和语义一起写下，比只写函数签名更完整。

```python
import torch
from torch import nn

def bc_update(model, optimizer, obs, action, device):
    # obs: [B, D]；action: [B]，取值 0..K-1。
    model.train()
    x = obs.to(device=device, dtype=torch.float32)
    y = action.to(device=device, dtype=torch.long)
    assert x.ndim == 2 and y.shape == (x.shape[0],)
    optimizer.zero_grad(set_to_none=True)
    logits = model(x)
    assert logits.ndim == 2 and logits.shape[0] == x.shape[0]
    loss = nn.functional.cross_entropy(logits, y)
    loss.backward()
    optimizer.step()
    return loss.detach()  # 频繁 .item() 可能引入设备同步。
```

这里先清梯度再前向，也可以在计算 loss 后、backward 前清理；关键是普通单步训练不要带入上一步梯度，有意累积时则不能每个微批都清理。通常在构造优化器前就把模型移到目标设备，并确保以后没有无意替换模型或参数对象。

**算例。** B=2、K=5，若所有 logits 为零，则每个动作概率为 1/5，交叉熵为 log5≈1.609。这个结果与两个动作标签具体是哪一类无关，是训练第一步的良好手算基准。若此时损失恰为零，优先检查目标、屏蔽与 reduction，而不是赞叹模型已经学会。

将 `model.train()` 放在更新入口，是为了避免刚完成验证后仍处于 eval 状态；它不负责开启所有梯度，也不会清理梯度。一个完整 epoch 还需要数据加载、验证与日志，但这些不应掩盖单步更新的正确性。进入 RL 后，目标会由轨迹构造，仍须先验证这一基本循环。

**常见错误。** backward 后立刻 zero_grad 再 step；模型在 GPU 而数据在 CPU；标签使用浮点类别编号；优化器引用旧模型；用一个 batch 的 mean loss 当整个 epoch 的样本均值而不加权。

**练习。** 先执行 backward，再执行 zero_grad，最后 step，参数会按本批梯度更新吗？**参考解答：** 不会按预期更新，因为梯度已被清除；若存在优化器状态或衰减，某些配置还可能有其他变化，所以正确结论不是“绝对什么都不会发生”。

**掌握标准。** 能独立写出单步训练，标出每个张量契约，并用均匀 logits 的损失验证输入输出链路。

## 知识点 032：eval、no_grad 与 detach 的边界

<!-- figure:f11:start -->
![反向传播与停止梯度](../assets/figures/f11.png)

**读图 · 反向传播与停止梯度**：右上损失可以回传到 w，下路经过 detach 后不能再沿原 y 回去。eval 改变 Dropout/BN 等行为，不自动关闭 autograd；no_grad 控制一段前向是否记录图。

*图中数值与轨迹为教学示意；两个面板是各自独立的正文手算；红色横线表示 detach 的反向边界。*
<!-- figure:f11:end -->


**优先级：P0。** 三个接口看起来都常在推理或目标计算附近出现，却控制不同事情。`model.eval()` 改变部分模块的行为，`torch.no_grad()` 控制其范围内是否记录普通反向图，`tensor.detach()` 则把某个已存在的张量从当前图中分离。必须按意图选择，不能把它们视为互相替代的“关闭训练”。

对 Dropout 和默认配置的 BatchNorm，eval 分别关闭随机失活、使用运行统计；普通线性层通常不因模式而改变公式。模型处于 eval 时，如果输入或参数需要梯度且没有关闭记录，依然可以做 backward。这在对输入求梯度等任务中有用途。反过来，no_grad 下的模型如果仍在 train 模式，Dropout 和 BN 的行为也不会自动变成评估模式。

```python
# 评估：同时明确模块行为与梯度记录。
model.eval()
with torch.no_grad():
    pred = model(obs)

# 固定目标：从计算图分离，不自动复制底层数据。
target = next_value.detach()
independent_target = next_value.detach().clone()
```

分离操作对数值通常没有改变：若 y=wx，`y.detach()` 仍保存 wx 的结果，但后续损失不能再通过它把梯度传给 w。默认情况下 detached 张量与原张量共享存储，因此修改一方可能影响另一方，甚至触发反向版本检查错误。需要独立快照时，应明确复制，而不是假设 detach 等于深拷贝。

**算例。** 设 w=2、x=3，$y=wx=6$。$L=y^2$ 时，$\frac{\partial L}{\partial w}=2y\cdot x=36$；若把整个 y 分离再构造 L，L 不再通过 y 依赖 w。在 RL 中，bootstrap target 常作为固定监督目标，这种停止梯度是算法的一部分；如果误把当前预测也 detach，价值网络就失去学习信号。

保存 rollout 时还要区分断开梯度与防止数据被覆盖。来自环境的 NumPy 数组可能复用同一缓冲区，`as_tensor` 又可能共享其内存；即使张量本来没有梯度，把引用直接放入列表也可能让历史观测变成最后一帧。应根据数据来源决定是否 clone 或 copy。

**常见错误。** 只调用 eval 就认为省去图开销；no_grad 采样时忘记模型模式；在训练 loss 上整体 detach；依赖共享内存的“历史快照”却继续原地修改源数据。

**练习。** 在 eval 模式下运行线性层，再对输出求和调用 backward，权重是否可能有梯度？**参考解答：** 可以，只要图被记录且权重需要梯度。eval 不关闭 autograd。

**掌握标准。** 能分别解释模式、图记录、图分离与存储复制，并说明某个目标为什么应当停止梯度。

## 知识点 033：梯度累积与正确的样本权重

<!-- figure:f17:start -->
![训练形状、微批权重与广播](../assets/figures/f17.png)

**读图 · 训练形状、微批权重与广播**：中图两个微批分别有 3、1 个样本，整体损失是 2×3/4+10×1/4=4。将两个 mean 等权平均得到 6，错误地放大了小微批影响。

*图中数值与轨迹为教学示意；中图柱宽表达 3:1 的样本数，右为 value=[[1],[3]] 减 target=[1,3]。*
<!-- figure:f17:end -->


**优先级：P0。** PyTorch 的 backward 通常把新梯度加进参数的 `.grad`，而不是自动覆盖。这让多损失、多微批次累积成为可能，但也意味着普通训练若忘记清理，会把多次更新混在一起。关键是你要优化哪一个明确的数学目标，而不是机械地规定“每四步更新一次”。

设一个有效 batch 共 M 个样本，被拆成若干微批，第 j 批有 $m_j$ 个，$\sum_jm_j=M$。若目标是所有样本损失的均值，则 $L=\frac1M\sum_j\sum_{i\in j}\ell_i=\sum_j\frac{m_j}{M}L_j$，其中 $L_j$ 是该微批平均损失。对它求梯度，正好等于对各微批按 $m_j/M$ 缩放后 backward 的累积。只有各批等大时，才等价于统一除以微批数量。

```python
# microbatches 是本次有效 batch 的有限列表；只在最后 step。
total = sum(x.shape[0] for x, y in microbatches)
optimizer.zero_grad(set_to_none=True)
for x, y in microbatches:
    logits = model(x)
    loss_sum = torch.nn.functional.cross_entropy(logits, y, reduction="sum")
    (loss_sum / total).backward()
optimizer.step()
```

**算例。** 两个微批分别有 3 个和 1 个样本，平均损失分别为 2 和 10。整体平均为 (3×2+1×10)/4=4，不能简单算 (2+10)/2=6。梯度同样需要样本数加权。如果序列还有 padding mask，分母可能应是有效 token 或有效时间步数量，而非名义 batch 大小，必须与目标定义一致。

累积梯度与一次大 batch 在“参数不变、目标可加、前向行为一致”等条件下具有对应关系。但 BatchNorm 每个微批的统计不同，Dropout 的采样、浮点求和顺序和某些 batch 级目标也可能造成差异；不能无条件宣称逐位等价。学习率调度和优化器 step 的计数，应按有效更新次数管理，而不是误跟着每次 backward 前进。

累积还不等于保留所有计算图。通常每个微批重新前向、反向，其图用完即可释放，不需要随手加 `retain_graph=True`。如果把每个带图 loss 都存在列表里并留到很晚才处理，反而可能抵消省显存的目的。清理位置、更新位置、归一化分母是审查此类代码的三个重点。

**常见错误。** 微批大小不同仍统一除数量；每个微批都清梯度；最后一个不足批次被丢掉；累积尚未结束就 step；把多次反向误当必须保留同一计算图。

**练习。** 三个微批有效样本数分别是 4、4、2，各自 mean loss 应乘什么系数？**参考解答：** 0.4、0.4、0.2，总权重为 1。若改用 sum loss，三者均除以总样本数 10。

**掌握标准。** 能从总目标推导缩放系数，处理不等微批和有效样本 mask，并说明与真正大 batch 不完全等价的情况。

## 知识点 034：CrossEntropyLoss 的输入为何是 logits

<!-- figure:f18:start -->
![交叉熵输入与动作概率比](../assets/figures/f18.png)

**读图 · 交叉熵输入与动作概率比**：直接把 logits=(2,0) 交给交叉熵得到绿色柱；先 softmax 再把结果当 logits 会变成红柱，损失和梯度都改变。稳定实现也无需直接计算巨大指数。

*图中数值与轨迹为教学示意；左侧概率解析计算，右侧对同一个已执行动作重新评分。*
<!-- figure:f18:end -->


**优先级：P0。** 多分类网络最后一层通常产生任意实数 logits，不必为正，也不必总和为 1。交叉熵实现内部会用稳定方式组合 log-softmax 与目标损失。如果先手动 softmax，再把概率传进去，它会把这些概率再次当作 logits，优化的就不是原来想要的目标。

单样本类别索引 y 对应损失 $L=-z_y+\log\sum_k\exp(z_k)$。数值稳定的写法先令 $m=\max_kz_k$，再计算 $\log\sum_k\exp(z_k)=m+\log\sum_k\exp(z_k-m)$。平移不改变 softmax，却能避免大 logits 的指数溢出。这也是直接调用稳定损失函数的好处：你不必先显式形成可能下溢到零的概率再取对数。

```python
logits = torch.tensor([[2.0, 0.0]])  # [B=1, K=2]
label = torch.tensor([0], dtype=torch.long)
loss = torch.nn.functional.cross_entropy(logits, label)
# 期望值约 0.126928；此处为手算目标，非运行结果声明。
```

**算例。** 上述 logits 对类别 0 的概率为 $\frac{e^2}{e^2+1}\approx0.881$，正确损失约 0.127。若先得到 (0.881,0.119) 再作为 logits，第二次 softmax 给类别 0 的概率仅约 0.682，损失约 0.383。差异不是一个常数缩放，梯度也变了，训练行为当然不同。

对 `[B,K]` logits，常见硬标签为 `[B]` 的 long 索引，范围是 0 到 K−1。软标签路径则使用对应形状的浮点分布，开发者需要确保非负且总和符合目标定义，不能期待接口替你纠正所有无效概率。多标签任务允许多个标签同时成立，常用逐类独立的 `BCEWithLogitsLoss`；五个互斥移动动作与五个可同时拥有的状态标签不是同一问题。

还需确认类别维的位置。对于 `[B,T,K]` 的序列 logits，不能假设所有损失函数都自动把最后一维识别为类别；可以明确展开为 `[B*T,K]`，同步展开标签与 mask，再按有效步数归一化。无效动作 mask 也必须与标签一致：若专家标签被屏蔽，损失异常首先说明数据或约束不一致。

一个序列小批若全部是 padding，就没有有效监督样本，平均损失的分母会变成零。应在数据组织或更新入口明确处理这种情况，不要通过随意加一个极小数把空训练步骤伪装成正常样本。

**常见错误。** 重复 softmax；把类别索引转换为浮点但保持 `[B]`；序列维与类别维放反；软标签没有归一化；把多标签任务当互斥多分类。

**练习。** 三分类 logits 全为 1000，正确类别任意，稳定交叉熵是多少？**参考解答：** 平移后都是 0，概率各为 1/3，损失 log3≈1.099；不应直接计算 exp(1000)。

**掌握标准。** 能从 logits 写出稳定交叉熵，检查硬/软标签 shape 与 dtype，并解释多分类与多标签的区别。接口细节见 [官方定义](https://docs.pytorch.org/docs/stable/generated/torch.nn.CrossEntropyLoss.html)。

## 知识点 035：广播、维度断言与静默错误

<!-- figure:f17:start -->
![训练形状、微批权重与广播](../assets/figures/f17.png)

**读图 · 训练形状、微批权重与广播**：右图本想 1 对 1、3 对 3，却广播成四种配对；非对角的 −2、2 是错误引入的额外项。关键 loss 应同时检查形状和样本顺序。

*图中数值与轨迹为教学示意；中图柱宽表达 3:1 的样本数，右为 value=[[1],[3]] 减 target=[1,3]。*
<!-- figure:f17:end -->


**优先级：P0。** 张量广播让不同形状的数组可以方便地逐元素运算，但它只根据维度兼容规则工作，不理解“这两个元素属于同一个样本”。因此最危险的错误往往不会报异常：代码成功运行，损失也会下降，却在优化完全不同的配对关系。

广播从末尾维度对齐；两维相等，或其中一维为 1，通常就可以扩展。缺失的前导维度按 1 处理。所以 `[B,1]` 减 `[B]`，后一项视为 `[1,B]`，结果为 `[B,B]`。原本想逐样本比较预测与目标，却变成每个预测都与所有目标比较。强化学习里的 value、return、advantage 和 log-prob 都应明确约定为同样的 `[B]` 或 `[B,1]`。

**算例。** value 为 `[[1],[3]]`，target 为 `[1,3]`。错误广播得到差值 `[[0,−2],[2,0]]`，平方均值为 2；正确逐样本误差应是 `[0,0]`，损失为 0。这个例子说明“代码能反传”并不能证明目标正确，小 batch 手算比观察长训练曲线更容易定位问题。

```python
value = value_head(obs).squeeze(-1)  # 只去掉已知的末尾单例维。
assert value.shape == returns.shape == (obs.shape[0],)
value_loss = (value - returns).square().mean()

assert new_logp.shape == old_logp.shape == advantage.shape
ratio = (new_logp - old_logp).exp()
```

不带参数的 `.squeeze()` 会移除所有大小为 1 的维度。B=32 时也许没问题，B=1 时却可能把 batch 维一起去掉，导致后续代码表现不同。显式 `.squeeze(-1)` 表达“只移除价值头最后那一维”，更符合数据契约。类似地，用 `.reshape(-1)` 暴力压平虽然能让 shape 一样，也可能掩盖时间轴和环境轴顺序不一致。

形状正确还不是最终保证。例如两个 `[B]` 张量若样本排序不同，仍会计算错误目标。因此应将样本标识、时间索引或容易识别的手工值用于调试，验证同一个索引确实表示同一条数据。尤其在 `[T,N]` 展开为 `[T*N]` 时，观测、动作和优势必须使用一致顺序。

**常见错误。** 依赖 MSE 等函数的警告却不读；看到 loss 能下降就接受广播；无参数 squeeze；只检查元素总数不检查维度语义；分别 shuffle 观测与目标。

**练习。** `[4,1]` 加 `[1,5]` 得到什么形状？为什么这对 pairwise 距离可能正确，对 value loss 却可能错误？**参考解答：** `[4,5]`。前者可能本来就要两两比较，后者通常要同样本一一对应，数学意图不同。

**掌握标准。** 能预测广播结果，为关键 loss 写 shape 断言，并用 B=1、B=2 的手算样本发现静默配对错误。

## 知识点 036：view、reshape、transpose 与 stride

<!-- figure:f19:start -->
![transpose 与 reshape 的元素次序](../assets/figures/f19.png)

**读图 · transpose 与 reshape 的元素次序**：中右的 shape 都是 [3,2]，数值位置却不同。沿中图一行移动需要跨原存储 3 个元素，因此 stride 改了；rollout 展平时必须让动作和优势遵循同样的排列。

*图中数值与轨迹为教学示意；原始 x 为行优先连续存储；transpose 可只改 shape 与 stride。*
<!-- figure:f19:end -->


**优先级：P0。** 张量不只是形状加一串数，还包含如何从索引找到底层存储的规则。stride 表示某个维度索引增加 1 时，存储位置跨过多少元素。转置可以只修改 shape 与 stride，不移动数据；因此它很便宜，却可能产生非连续视图，影响后续重塑与计算。

对于连续的 `[2,3]` 行优先张量，stride 通常是 `(3,1)`。转置成 `[3,2]` 后，stride 变成 `(1,3)`，底层顺序没有变化。`view` 只能在布局兼容时用新形状解释同一存储；`reshape` 会尽量返回视图，必要时复制。非连续张量并非所有 view 都失败，真正条件是相邻维度的 stride 能否满足对应合并关系，因此不能把“非连续”简化成绝对禁止 view。

```python
x = torch.tensor([[0, 1, 2], [3, 4, 5]])
y = x.transpose(0, 1)         # 逻辑内容 [[0,3],[1,4],[2,5]]
z = y.reshape(-1)            # 逻辑顺序 [0,3,1,4,2,5]，此处需复制。
# y.view(-1) 在这个例子中布局不兼容。
```

**案例。** rollout 存为 `[T,N,D]`，想按时间优先展开样本，可以直接 reshape 成 `[T*N,D]`。若先 transpose 为 `[N,T,D]` 再 reshape，样本顺序就变成环境优先。两者形状和元素数量相同，却有不同排列；动作与优势必须跟随同一种变换。把 `.reshape(N,T,D)` 当成 transpose，会把数值重新分组，产生完全不同的轨迹。

`contiguous()` 可在需要时生成连续存储，已经连续时通常无需复制。到处补它可能隐藏真正的数据布局问题，并引入额外内存与拷贝。应先判断后续算子是否要求布局，以及是否确实需要交换轴。对客户端推理导出，显式约定输入轴顺序尤其重要，不能只依赖 Python 里某次 reshape 恰好可运行。

视图通常与原张量共享数据；修改视图也可能修改原张量。与 detach 一样，布局操作和数据所有权是两个独立维度。如果代码需要保存不可变快照，要明确 clone；如果只需换观察方式，则不必无端复制。

**常见错误。** 用 reshape 替代轴交换；认为 reshape 总是零拷贝；把所有 view 失败都用 contiguous 掩盖；检查 shape 却不检查逻辑元素次序；无意原地修改共享存储。

**练习。** 上例 x 直接 reshape 为 `[3,2]`，内容是否等于 x 的转置？**参考解答：** 不等，reshape 得到 `[[0,1],[2,3],[4,5]]`，转置得到 `[[0,3],[1,4],[2,5]]`，两者虽然 shape 相同，语义不同。

**掌握标准。** 能用小矩阵说明 stride、视图与复制，选择正确的轴交换和展开顺序。兼容条件见 [view 官方文档](https://docs.pytorch.org/docs/stable/generated/torch.Tensor.view.html)。

## 知识点 037：动作采样与旧 log-prob 的保存

<!-- figure:f18:start -->
![交叉熵输入与动作概率比](../assets/figures/f18.png)

**读图 · 交叉熵输入与动作概率比**：右图旧、新策略必须评估同一状态下同一个实际执行的“向右”，并保持合法动作条件一致。采样时保存 action 与 old_logp，更新时重采样就失去原概率比意义。

*图中数值与轨迹为教学示意；左侧概率解析计算，右侧对同一个已执行动作重新评分。*
<!-- figure:f18:end -->


**优先级：P0。** 策略网络输出的不是动作本身，而是动作分布的参数。训练时通常从分布采样，以便探索并计算采样动作的概率；评估时是否采用 argmax，要按评估协议决定。PPO 还需要保存动作实际生成时的旧概率，之后才能比较新策略对同一个动作的看法。

离散策略可用 logits 构造 Categorical 分布。对观测 batch `[B,D]`，logits 为 `[B,K]`，采样动作和对应 log-prob 都为 `[B]`。概率比 $\rho=\exp(\log\pi_{\mathrm{new}}(a\mid s)-\log\pi_{\mathrm{old}}(a\mid s))$。差值再取指数通常比直接对两个很小概率做除法更稳定，且清楚表达“相同状态、相同动作、不同策略参数”的比较。

```python
# 采样侧：model(obs) 约定返回 logits [B,K]、value [B,1]。
with torch.no_grad():
    logits, value = model(obs)
    dist = torch.distributions.Categorical(logits=logits)
    action = dist.sample()
    old_logp = dist.log_prob(action)
    stored = (obs.clone(), action.clone(), old_logp.clone(),
              value.squeeze(-1).clone())
# 更新侧重新计算 new_dist.log_prob(stored_action)，不重新采样标签。
```

**算例。** 旧策略对“向右”的概率为 0.2，采样恰好向右；新策略给它 0.3，则 ratio=0.3/0.2=1.5。若更新时重新采样成停留再算 log-prob，就不再是同一事件的概率比。旧 log-prob 应对应当时真正采样的分布，包括合法动作 mask；不能事后用已更新的模型重新算出一个所谓旧值。

多个独立动作分量的联合概率为各分量概率乘积，因此联合 log-prob 要按动作分量求和，最后留下每个样本一个数。如果动作分量不是独立的，例如先选技能再选依赖技能的目标，必须使用条件分解。连续动作经 tanh 压缩时还涉及变量变换的 Jacobian 修正，不能把压缩前的高斯 log-prob 直接当成最终动作密度。

rollout 缓冲通常保存观测、动作、旧 log-prob、value、奖励、终止信息及所需 mask；RNN 还需记录序列边界和隐藏状态。保存 clone 不是为了“保证可导”，而是避免外部循环覆盖同一个存储。旧策略版本号也能帮助发现异步采样中的陈旧数据。

**常见错误。** 把 logits 当概率直接采样；保存最大概率动作的 log-prob 而实际执行了采样动作；更新时重采样；分量 log-prob 未求和；旧/新分布使用不同 mask。

**练习。** 两个条件独立动作分量的采样概率分别为 0.5 和 0.2，联合 log-prob 是多少？**参考解答：** $\log0.5+\log0.2=\log0.1\approx-2.303$。不是两个 log-prob 的平均值。

**掌握标准。** 能完整追踪一个已执行动作从采样到更新的概率记录，并检查 shape、mask 和策略版本一致性。

## 知识点 038：混合精度、梯度缩放与裁剪顺序

<!-- figure:f13:start -->
![梯度范数裁剪与 AMP 顺序](../assets/figures/f13.png)

**读图 · 梯度范数裁剪与 AMP 顺序**：右图原范数仅 0.5，本不需要裁剪；先裁放大后的 512 会把最终范数错压到 0.00098。应在有效 batch 累积完成后先 unscale，再 clip。

*图中数值与轨迹为教学示意；两个面板分别按正文算例精确计算；右侧阈值为 1。*
<!-- figure:f13:end -->


**优先级：P1。** 混合精度让适合的算子使用较低精度，以降低部分显存与计算成本，同时保留敏感计算的精度。它不是把所有张量手动 `.half()`。FP16 表示范围较窄，小梯度可能下溢；梯度缩放通过先放大 loss，使反向数值保持可表示，更新前再恢复真实尺度。

若缩放因子为 S，则对 SL 反传得到 Sg，更新前除以 S 才恢复原梯度。如果在恢复前按阈值 c 裁剪，相当于把真实梯度阈值改成 c/S，严重改变训练。正确顺序是 autocast 前向与损失、scale 后 backward、unscale、裁剪、scaler.step、scaler.update。下面片段只适用于已准备好的 CUDA FP16 教学场景，硬件和安装版本应先核对。

```python
scaler = torch.amp.GradScaler("cuda")  # 在训练循环外创建并持久保留。
# 每次有效更新：
optimizer.zero_grad(set_to_none=True)
with torch.autocast(device_type="cuda", dtype=torch.float16):
    loss = loss_fn(model(x), y)
scaler.scale(loss).backward()
scaler.unscale_(optimizer)
torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
scaler.step(optimizer)
scaler.update()
```

**算例。** 真实梯度范数是 0.5，S=1024，缩放后为 512。若先裁到 1 再除 S，最终范数变成约 0.00098，原本根本不该裁剪的梯度被压小数百倍。BF16 的指数范围与 FP16 不同，通常不具有相同的缩放需求，但尾数精度及算子支持仍需评估。

梯度累积时，应在整个有效 batch 完成后统一 unscale 与 step，并保持这次累积的缩放因子一致。GradScaler 可能因非有限梯度跳过更新，所以日志与调度器应区分“尝试更新”与实际完成更新。对微型竞技场小网络，AMP 未必带来明显加速，应先测瓶颈。

**常见错误。** 裁剪顺序反了；每个微批都 unscale；每步重新创建 scaler；发现溢出就以为提高 S 总能解决；把 BF16 和 FP16 的动态范围视为相同。

**练习。** S=128，缩放梯度范数 256，真实范数是多少，阈值 1 时最后范数应是多少？**参考解答：** 真实范数为 2，正确裁剪后为 1。

**掌握标准。** 能解释缩放原理与操作顺序，核对有效 batch 边界，并用实际计时决定是否启用。细节见 [官方 AMP 示例](https://docs.pytorch.org/docs/stable/notes/amp_examples.html)。

## 知识点 039：可恢复实验与 checkpoint 契约

<!-- figure:f20:start -->
![部署契约、checkpoint 与瓶颈](../assets/figures/f20.png)

**读图 · 部署契约、checkpoint 与瓶颈**：中图强调状态组成，不表达体积比例。参数之外，优化器、调度计数、随机与环境状态都可能影响续训下一步；协议和版本也必须能追溯。

*图中数值与轨迹为教学示意；右侧假设各阶段串行且不重叠；真实流水线需测等待和重叠。*
<!-- figure:f20:end -->


**优先级：P0。** “能加载模型做推理”与“能从中断处继续同一实验”是不同要求。前者主要需要权重、结构与预处理协议；后者还需要优化器状态、训练进度和随机状态。只保存 `.pth` 权重文件，并不能自动保留训练过程中的动量、归一化统计和采样上下文。

一个恢复点可理解为状态集合 C=(θ,O,S,k,R,E)，其中 θ 是模型参数与 buffer，O 是优化器状态，S 是调度器或 AMP scaler 状态，k 是更新/环境步数，R 是随机数状态，E 是环境与数据管线状态。配置、代码版本、依赖版本和特征协议也要可追溯，否则同一数字文件可能被不同程序解释成不同模型。

```python
# 最小结构示意；生产版还需补充下文的随机与环境状态。
checkpoint = {
    "model": model.state_dict(),
    "optimizer": optimizer.state_dict(),
    "update": update_index,
    "env_steps": env_steps,
    "config": config,
    "torch_rng": torch.get_rng_state(),
}
torch.save(checkpoint, checkpoint_path)
```

**案例。** 两次加载同一策略权重后，A 恢复 Adam 的一二阶矩和当前学习率，B 新建优化器从初始学习率训练。即使下一批数据一样，更新也可能不同。另一个常见问题是遗漏观测归一化统计：模型权重完全相同，但输入尺度变化，动作便不一致。BN 运行统计属于模型 buffer，应随 state_dict 保存；外部归一化器则需独立纳入。

完整 RL 恢复还可能需要 Python 与 NumPy 随机状态、CUDA 各设备随机状态、回放缓冲、对手池、环境快照、RNN 隐藏状态和采样队列。若环境无法序列化，可以选择在 episode 或 rollout 边界保存，并明确“可继续训练但不保证逐步一致”。异步进程调度、非确定性算子、不同硬件和版本也可能妨碍逐位重现，不能承诺 seed 一致就必然完全相同。

恢复流程应先建立匹配的结构和优化器，加载各状态，核对计数与版本，再做固定观测的前向比较。存储还要考虑写入中断：常见做法是写完整临时文件，再在同一文件系统中替换最终文件，避免半个 checkpoint 被当成最新可用版本。加载选项和可反序列化对象范围依安装版本核对，训练资产来源也应明确。

**常见错误。** 只存网络参数；把 state_dict 的引用长期当成不会变化的内存快照；遗漏外部归一化和对手版本；恢复后学习率调度重置；把“统计上可复现”说成“逐位一致”。

**练习。** 固定观测加载前后 logits 一致，是否证明能精确续训？**参考解答：** 不能，只验证了该输入下前向一致。还需检查优化器、随机状态、下一批数据、环境和计数，才能验证后续更新是否匹配。

**掌握标准。** 能列出推理包与训练恢复包的差异，并实际设计中断前后的一步或短段对照。基础接口见 [官方保存与加载教程](https://docs.pytorch.org/tutorials/beginner/saving_loading_models.html)。

## 知识点 040：CPU/GPU 都不忙时怎样定位性能瓶颈

<!-- figure:f20:start -->
![部署契约、checkpoint 与瓶颈](../assets/figures/f20.png)

**读图 · 部署契约、checkpoint 与瓶颈**：右图网络更新只占 10 毫秒，消除它仍需 90 毫秒，上限为 100/90≈1.11。先找耗时与等待的主要来源，再决定加速环境、通信还是模型。

*图中数值与轨迹为教学示意；右侧假设各阶段串行且不重叠；真实流水线需测等待和重叠。*
<!-- figure:f20:end -->


**优先级：P0。** 训练慢并不必然意味着缺 GPU。游戏 RL 往往花大量时间在环境 step、进程通信、Python 循环、数组转换和小批推理上。CPU 总占用低，也可能有一个关键线程满载，其余核心空闲；GPU 利用率低则可能是在等待数据。先建立时间分解，再决定并行与设备方案。

把一次采样—更新循环近似写为 $t_{\mathrm{cycle}}=t_{\mathrm{env}}+t_{\mathrm{encode}}+t_{\mathrm{transfer}}+t_{\mathrm{infer}}+t_{\mathrm{store}}+t_{\mathrm{update}}$，流水线有重叠时还需记录等待和队列，不能简单把各阶段总时间相加当端到端时间。吞吐可报告 env_steps/s、样本/s、updates/s；延迟则需要单次响应的分布，两者回答不同问题。批处理通常提高吞吐，但可能增加等待一批凑齐的延迟。

GPU 操作常异步提交。若用 CPU 计时器只包住一次 kernel 调用，测到的可能是提交时间而非完成时间。局部基准可在计时边界适当同步或使用 CUDA events，并先预热；不要为了测得清楚就在训练每一步额外同步，把原本可重叠的流水线测慢。CPU 段可用高分辨率计时器，完整诊断再借助 profiler 查看算子、拷贝和等待。

**算例。** 一个循环 100 毫秒，其中环境 70、通信 20、网络更新 10。即使把网络更新加速到无限快，循环也至少需要 90 毫秒，最大加速约 100/90≈1.11 倍。先优化环境与数据传递，往往比换更强 GPU 更有效。这是 Amdahl 思路在训练系统中的直接应用。

**案例。** 10×10 竞技场的小 MLP 每次只推理一个样本，GPU 运算本身很快，但往返拷贝、启动与 `.item()` 同步占大头。可比较 CPU 单环境、CPU 批推理、多个环境集中 GPU 推理，固定模型与总步数记录端到端耗时。若环境对象每步还被完整序列化传进进程，减少传输内容或让 worker 持有状态可能更关键。

优化后需要同时检查正确性与效果。批大小改变可能改变优化行为，并行环境改变采样分布与随机顺序，异步队列会引入旧策略数据。性能提升应附带相同预算下的任务指标，不能只展示 steps/s 而忽略训练是否仍然学会。

**常见错误。** 只看任务管理器平均占用；用未同步的 GPU 计时作结论；过早增加进程导致通信反而变重；频繁把 GPU 张量变成 Python 数字；更改 batch 后直接宣称算法更有效。

**练习。** 环境与通信占 80%，模型计算占 20%，模型加速两倍后总加速多少？**参考解答：** 新时间比例为 0.8+0.2/2=0.9，总加速为 1/0.9≈1.11 倍，远小于 2 倍。

**掌握标准。** 能制作一次循环的时间分解，解释 GPU 异步计时，并用瓶颈占比决定下一项优化而非凭设备占用猜测。

## 本章延伸阅读与实施约定

计算图基础见 [PyTorch Autograd 教程](https://docs.pytorch.org/tutorials/beginner/basics/autogradqs_tutorial.html)，广播规则见 [官方 broadcasting 说明](https://docs.pytorch.org/docs/stable/notes/broadcasting.html)，动作分布的 batch/event shape 见 [distributions 文档](https://docs.pytorch.org/docs/stable/distributions.html)，测量工具见 [PyTorch Profiler 教程](https://docs.pytorch.org/tutorials/recipes/recipes/profiler_recipe.html)。文档的 `stable` 链接会变化，落地项目应在依赖文件与实验配置中固定经过本机验证的版本，再对照对应文档；本章未替你假定某个本地安装版本。
