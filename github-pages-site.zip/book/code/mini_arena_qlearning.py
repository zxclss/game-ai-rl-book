"""A small, reproducible tabular learning experiment; Python standard library.

The 5x5 map is a curriculum sublevel of the book's 10x10 arena. This is a fixed
fully observable navigation task, not a claim of general game intelligence.
Actions: up, down, left, right, stay. The time limit is an external truncation.
"""

import argparse
import json
import random
from collections import deque
from dataclasses import dataclass
from pathlib import Path


MOVES = ((-1, 0), (1, 0), (0, -1), (0, 1), (0, 0))


@dataclass
class Transition:
    obs: int
    reward: float
    terminated: bool
    truncated: bool
    success: bool


class Arena:
    size = 5
    start = (0, 0)
    goal = (4, 4)
    walls = frozenset({(1, 1), (1, 2), (2, 3), (3, 1)})
    hazards = frozenset({(2, 1)})

    def __init__(self, max_steps=60):
        self.max_steps = max_steps
        self.reset()

    def encode(self, position):
        return position[0] * self.size + position[1]

    def reset(self):
        self.position = self.start
        self.steps = 0
        self.done = False
        return self.encode(self.position)

    def destination(self, position, action):
        dr, dc = MOVES[action]
        nxt = (position[0] + dr, position[1] + dc)
        if not (0 <= nxt[0] < self.size and 0 <= nxt[1] < self.size):
            return position
        return position if nxt in self.walls else nxt

    def step(self, action):
        if self.done:
            raise RuntimeError("reset is required before stepping a finished episode")
        if not isinstance(action, int) or not 0 <= action < len(MOVES):
            raise ValueError("action must be an integer in [0, 4]")
        self.position = self.destination(self.position, action)
        self.steps += 1
        success = self.position == self.goal
        terminated = success or self.position in self.hazards
        truncated = not terminated and self.steps >= self.max_steps
        self.done = terminated or truncated
        reward = 1.0 if success else (-1.0 if terminated else -0.01)
        return Transition(self.encode(self.position), reward, terminated, truncated, success)


def greedy_action(q, state):
    return max(range(len(MOVES)), key=lambda a: q[state][a])


def train(seed, episodes=2500, gamma=0.97, learning_rate=0.2):
    rng = random.Random(seed)
    env = Arena()
    q = [[0.0] * len(MOVES) for _ in range(env.size**2)]
    steps = 0
    for episode in range(episodes):
        state = env.reset()
        epsilon = max(0.05, 1.0 - episode / (0.8 * episodes))
        while True:
            action = rng.randrange(len(MOVES)) if rng.random() < epsilon else greedy_action(q, state)
            result = env.step(action)
            # External truncation still bootstraps from the actual final state.
            target = result.reward
            if not result.terminated:
                target += gamma * max(q[result.obs])
            q[state][action] += learning_rate * (target - q[state][action])
            steps += 1
            state = result.obs
            if result.terminated or result.truncated:
                break
    return q, steps


def bfs_actions(env):
    queue = deque([(env.start, [])])
    seen = {env.start}
    while queue:
        position, path = queue.popleft()
        if position == env.goal:
            return path
        for action in range(4):
            nxt = env.destination(position, action)
            if nxt in seen or nxt in env.hazards:
                continue
            seen.add(nxt)
            queue.append((nxt, path + [action]))
    raise RuntimeError("The teaching map has no safe route")


def evaluate(policy, episodes=200, seed=9000):
    env = Arena()
    rng = random.Random(seed)
    wins, total_steps, total_reward = 0, 0, 0.0
    for _ in range(episodes):
        state = env.reset()
        while True:
            result = env.step(policy(state, env.steps, rng))
            total_steps += 1
            total_reward += result.reward
            state = result.obs
            if result.terminated or result.truncated:
                wins += int(result.success)
                break
    return {"episodes": episodes, "success_rate": wins / episodes,
            "mean_steps": total_steps / episodes, "mean_return": total_reward / episodes}


def self_check():
    env = Arena(max_steps=1)
    before = env.reset()
    outcome = env.step(0)
    assert outcome.obs == before and outcome.truncated and not outcome.terminated
    env = Arena()
    path = bfs_actions(env)
    for action in path:
        outcome = env.step(action)
    assert outcome.success and outcome.terminated and not outcome.truncated
    assert len(path) == 8
    env.reset()
    for action in (1, 1, 3):
        outcome = env.step(action)
    assert outcome.reward == -1 and outcome.terminated and not outcome.success


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--episodes", type=int, default=2500)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.episodes < 1:
        parser.error("--episodes must be positive")
    self_check()
    baseline = evaluate(lambda state, step, rng: rng.randrange(len(MOVES)))
    path = bfs_actions(Arena())
    rule = evaluate(lambda state, step, rng: path[step])
    runs = []
    for seed in (11, 22, 33):
        q, steps = train(seed, episodes=args.episodes)
        result = evaluate(lambda state, step, rng: greedy_action(q, state))
        runs.append({"training_seed": seed, "training_episodes": args.episodes,
                     "environment_steps": steps, **result})
    report = {
        "task": "fixed 5x5 fully observable navigation teaching sublevel",
        "limits": "Greedy evaluations repeat a deterministic fixed map. These are not independent"
                  " generalization trials. No unseen-map or opponent-strength claim is supported.",
        "random": baseline, "bfs_rule": rule, "q_learning": runs,
    }
    rendered = json.dumps(report, ensure_ascii=False, indent=2)
    print(rendered)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
