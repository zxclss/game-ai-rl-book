"""Small, dependency-free numerical exercises accompanying the study notes.

This is not a trainer. next_values must refer to final pre-reset observations.
Reward r[t] is received after action a[t].
"""

from math import exp, isclose, log, log1p


def gae(rewards, values, next_values, terminated, continues, gamma, lam):
    """Compute GAE for a chronological stream with explicit reset boundaries.

    terminated controls bootstrapping; continues controls tracing into the next
    row. A truncated/reset boundary bootstraps but does not trace across reset.
    There is no sampled residual beyond the end of this finite buffer.
    """
    n = len(rewards)
    if any(len(x) != n for x in (values, next_values, terminated, continues)):
        raise ValueError("All transition arrays must have the same length")
    if any(t and c for t, c in zip(terminated, continues)):
        raise ValueError("A terminated episode cannot continue into the next row")
    advantages = [0.0] * n
    tail = 0.0
    for t in range(n - 1, -1, -1):
        bootstrap = 0.0 if terminated[t] else next_values[t]
        delta = rewards[t] + gamma * bootstrap - values[t]
        tail = delta + gamma * lam * (tail if continues[t] else 0.0)
        advantages[t] = tail
    return advantages, [a + v for a, v in zip(advantages, values)]


def ppo_surrogate(ratio, advantage, epsilon=0.2):
    clipped = min(max(ratio, 1.0 - epsilon), 1.0 + epsilon)
    return min(ratio * advantage, clipped * advantage)


def stable_softmax(logits):
    if not logits:
        raise ValueError("Expected a nonempty list of finite logits")
    maximum = max(logits)
    weights = [exp(z - maximum) for z in logits]
    total = sum(weights)
    return [w / total for w in weights]


def dpo_loss(chosen, rejected, ref_chosen, ref_rejected, beta=0.1):
    """Arguments are sequence log probabilities, not raw probabilities."""
    margin = beta * ((chosen - ref_chosen) - (rejected - ref_rejected))
    # softplus(-margin), evaluated without exp of a large positive argument.
    return max(-margin, 0.0) + log1p(exp(-abs(margin)))


def check_close(actual, expected):
    assert len(actual) == len(expected)
    assert all(isclose(a, b, abs_tol=1e-10) for a, b in zip(actual, expected))


def main():
    advantages, targets = gae(
        [0, 0, 1], [0.2, 0.3, 0.4], [0.3, 0.4, 0],
        [False, False, True], [True, True, False], 0.9, 0.8,
    )
    check_close(advantages, [0.42424, 0.492, 0.6])
    check_close(targets, [0.62424, 0.792, 1.0])

    terminal, _ = gae([0], [0.2], [0.5], [True], [False], 0.9, 0.8)
    truncated, _ = gae([0], [0.2], [0.5], [False], [False], 0.9, 0.8)
    check_close(terminal, [-0.2])
    check_close(truncated, [0.25])
    # The second row is from a new episode and must not leak into the first.
    reset_boundary, _ = gae(
        [0, 100], [0.2, 0], [0.5, 0],
        [False, True], [False, False], 0.9, 0.8,
    )
    check_close(reset_boundary, [0.25, 100.0])
    check_close(gae([], [], [], [], [], 0.9, 0.8)[0], [])

    for ratio, advantage, expected in [
        (1.4, 2, 2.4), (0.6, 2, 1.2), (0.6, -2, -1.6), (1.4, -2, -2.8),
        (1.0, 2, 2), (1.0, -2, -2),
    ]:
        assert isclose(ppo_surrogate(ratio, advantage), expected)
    # Outside the favorable clipping boundary, further change earns no gain.
    assert isclose(ppo_surrogate(1.4, 2), ppo_surrogate(1.8, 2))
    assert isclose(ppo_surrogate(0.6, -2), ppo_surrogate(0.2, -2))

    check_close(stable_softmax([1000, 1000, 1000]), [1 / 3] * 3)
    check_close(stable_softmax([1, 2, 3]), stable_softmax([1001, 1002, 1003]))
    initial = dpo_loss(-2, -3, -2, -3)
    assert isclose(initial, log(2))
    assert dpo_loss(-1, -3, -2, -3) < initial
    assert dpo_loss(-2, -2, -2, -3) > initial
    print("PASS: GAE targets, reset boundaries, PPO clipping, softmax, DPO direction")


if __name__ == "__main__":
    main()
