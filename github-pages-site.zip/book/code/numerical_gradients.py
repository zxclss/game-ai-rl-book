"""Analytic vs central-difference gradients for teaching; standard library only.

PPO examples are chosen away from clipping kinks, where a derivative is defined.
This tests one-sample softmax policy losses, not a full PPO training system.
"""

import math


def softmax(logits):
    m = max(logits)
    e = [math.exp(v - m) for v in logits]
    return [v / sum(e) for v in e]


def finite_difference(fn, x, h=1e-6):
    result = []
    for j in range(len(x)):
        plus, minus = x[:], x[:]
        plus[j] += h
        minus[j] -= h
        result.append((fn(plus) - fn(minus)) / (2 * h))
    return result


def cross_entropy(logits, action):
    m = max(logits)
    return m + math.log(sum(math.exp(x - m) for x in logits)) - logits[action]


def ppo_loss(logits, action, old_probability, advantage, epsilon=0.2):
    ratio = softmax(logits)[action] / old_probability
    clipped = min(max(ratio, 1 - epsilon), 1 + epsilon)
    return -min(ratio * advantage, clipped * advantage)


def ppo_gradient(logits, action, old_probability, advantage, epsilon=0.2):
    probs = softmax(logits)
    ratio = probs[action] / old_probability
    plateau = (advantage > 0 and ratio > 1 + epsilon) or (
        advantage < 0 and ratio < 1 - epsilon
    )
    if plateau:
        return [0.0] * len(logits)
    return [-advantage * ratio * ((1.0 if j == action else 0.0) - p)
            for j, p in enumerate(probs)]


def verify(expected, measured, label):
    error = max(abs(a - b) for a, b in zip(expected, measured))
    assert error < 1e-7, (label, expected, measured, error)
    return error


def main():
    logits = [0.2, -0.1, 0.4]
    probs = softmax(logits)
    expected = [p - (1 if j == 1 else 0) for j, p in enumerate(probs)]
    errors = [verify(expected, finite_difference(lambda z: cross_entropy(z, 1), logits), "CE")]
    for advantage in (2.0, -2.0):
        for ratio in (0.6, 1.0, 1.4):
            old_probability = probs[0] / ratio
            assert 0 < old_probability < 1
            actual = finite_difference(lambda z: ppo_loss(z, 0, old_probability, advantage), logits)
            expected = ppo_gradient(logits, 0, old_probability, advantage)
            errors.append(verify(expected, actual, (advantage, ratio)))
    # One descent step must increase probability for positive advantage.
    gradient = ppo_gradient(logits, 0, probs[0], 2.0)
    updated = [z - 0.01 * g for z, g in zip(logits, gradient)]
    assert softmax(updated)[0] > probs[0]
    print(f"PASS: cross-entropy and six PPO gradient cases; max error={max(errors):.3e}")


if __name__ == "__main__":
    main()
