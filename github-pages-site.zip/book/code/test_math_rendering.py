"""Regression tests for math delimiters, Markdown code and table boundaries."""
from html.parser import HTMLParser
from pathlib import Path
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from build_book import render_markdown


class MathNodes(HTMLParser):
    def __init__(self, html):
        super().__init__()
        self.formulas = []
        self.feed(html)

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if "data-tex" in attrs:
            self.formulas.append((tag, attrs["data-tex"]))


class MathRenderingTests(unittest.TestCase):
    def render(self, source):
        html = render_markdown(source, "test")
        self.assertNotRegex(html, r"BOOK(?:MATHFORMULA|CODEBLOCK|INLINECODE)\d+TOKEN")
        return html, MathNodes(html).formulas

    def test_supported_delimiters(self):
        _, nodes = self.render(r"行内 $x_i^2$ 和 \(y_j\)。" + "\n\n$$\nz=x+y\n$$\n\n" + r"\[w=1\]")
        self.assertEqual(nodes, [("span", "x_i^2"), ("span", "y_j"), ("div", "z=x+y"), ("div", "w=1")])

    def test_code_is_literal(self):
        source = r"`$x$` 和 ``包含 ` 和 \(y\)``，公式 $z$。" + "\n\n" + "```python\nx = '$a$'\n```\n\n~~~text\n\\[b\\]\n~~~\n\n    $c$\n"
        html, nodes = self.render(source)
        self.assertEqual(nodes, [("span", "z")])
        self.assertIn("<code>$x$</code>", html)
        self.assertIn("<code>包含 ` 和 \\(y\\)</code>", html)
        self.assertEqual(html.count("<pre>"), 3)

    def test_math_survives_table_and_html_escaping(self):
        html, nodes = self.render('| 名称 | 公式 |\n|---|---|\n| 条件 | $P(a|s)$ |\n\n$x<y$ 和 $\\text{"a"}$')
        self.assertEqual(nodes, [("span", "P(a|s)"), ("span", "x<y"), ("span", r'\text{"a"}')])
        self.assertEqual(html.count("<td>"), 2)
        self.assertIn("&lt;", html)

    def test_escaped_dollars_and_unclosed_math_stay_text(self):
        html, nodes = self.render(r"价格 \$5 和 \$10；未闭合 $x；代码 `a_b`。")
        self.assertEqual(nodes, [])
        self.assertIn("<code>a_b</code>", html)

    def test_nested_fence_does_not_consume_following_formula(self):
        _, nodes = self.render('- 示例\n\n  ```text\n  $literal$\n  ```\n\n公式 $x_t$。')
        self.assertEqual(nodes, [("span", "x_t")])

    def test_intro_symbol_table_has_explicit_math(self):
        root = Path(__file__).resolve().parents[1]
        source = (root / "00_前言与阅读方法.md").read_text(encoding="utf-8")
        section = source.split("## 符号和张量约定\n", 1)[1].split("\n## ", 1)[0]
        _, nodes = self.render(section)
        formulas = {tex for _, tex in nodes}
        for tex in ("s_t", "o_t", "a_t", "r_t", "R_{t+1}", r"\pi_\theta",
                    r"\mu_\theta", "b_t", "c_t", "d_k", r"B=T\times N"):
            self.assertIn(tex, formulas)
        rows = [line for line in section.splitlines() if line.startswith("| $")]
        self.assertEqual(len(rows), 9)
        for row in rows:
            _, symbols = self.render(row.split("|")[1])
            self.assertGreaterEqual(len(symbols), 2)

    def test_appendix_derivatives_have_explicit_math(self):
        root = Path(__file__).resolve().parents[1]
        _, nodes = self.render((root / "附录A_实验与自测.md").read_text(encoding="utf-8"))
        formulas = {tex for _, tex in nodes}
        self.assertIn(r"\frac{\partial\log p_a}{\partial z_j}=\mathbf{1}[j=a]-p_j", formulas)
        self.assertIn(r"-A\rho(\mathbf{1}[j=a]-p_j)", formulas)


if __name__ == "__main__":
    unittest.main()
