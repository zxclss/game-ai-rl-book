// Run with Node.js and Playwright installed; validates the actual offline reader.
const { chromium } = require('playwright');
const { resolve, join } = require('node:path');
const { pathToFileURL } = require('node:url');
const fs = require('node:fs');
const assert = require('node:assert/strict');

(async () => {
  const root = resolve(__dirname, '..');
  const browser = await chromium.launch({ headless: true, ...(process.env.BROWSER_CHANNEL ? { channel: process.env.BROWSER_CHANNEL } : {}) });
  try {
    const page = await browser.newPage({ viewport: { width: 1365, height: 1000 } });
    const errors = [], warnings = [], failedRequests = [];
    page.on('pageerror', error => errors.push(error.message));
    page.on('console', message => {
      if (message.type() === 'error') errors.push(message.text());
      if (message.type() === 'warning') warnings.push(message.text());
    });
    page.on('requestfailed', request => failedRequests.push(request.url()));
    await page.goto(pathToFileURL(join(root, 'index.html')).href, { waitUntil: 'load' });
    await page.evaluate(() => document.fonts.ready);
    const audit = await page.evaluate(() => {
      const formulas = [...document.querySelectorAll('[data-tex]')];
      const parseErrors = [];
      for (const el of formulas) {
        try { katex.renderToString(el.dataset.tex, { throwOnError: true, strict: 'error' }); }
        catch (error) { parseErrors.push({ tex: el.dataset.tex, error: error.message }); }
      }
      return {
        formulas: formulas.length,
        rendered: document.querySelectorAll('[data-tex] > .katex, [data-tex] > .katex-display').length,
        failures: document.querySelectorAll('.katex-error, .math-fallback').length,
        parseErrors,
        formulasInCode: document.querySelectorAll('code [data-tex], pre [data-tex]').length,
        residualMarkers: /BOOK(?:MATHFORMULA|CODEBLOCK|INLINECODE)\d+TOKEN/.test(document.querySelector('main').textContent),
        byChapter: [...document.querySelectorAll('.chapter')].map(el => ({
          heading: el.querySelector('h2')?.textContent,
          formulas: el.querySelectorAll('[data-tex]').length,
        })),
        fontsLoaded: [...document.fonts].filter(font => font.family.startsWith('KaTeX') && font.status === 'loaded').length,
      };
    });
    audit.layout = [];
    const symbolTable = page.locator('.chapter').first().locator('table').nth(1);
    audit.symbolTable = await symbolTable.locator('tbody tr').evaluateAll(rows => ({
      rows: rows.length,
      symbolCellsRendered: rows.filter(row => row.cells[0].querySelectorAll('[data-tex] .katex').length >= 2).length,
      formulas: rows.reduce((count, row) => count + row.querySelectorAll('[data-tex]').length, 0),
    }));
    await symbolTable.screenshot({ path: join(root, 'reports', 'math-symbols.png') });
    for (const width of [1365, 390]) {
      await page.setViewportSize({ width, height: 1000 });
      audit.layout.push(await page.evaluate(() => ({
        width: innerWidth,
        pageOverflow: document.documentElement.scrollWidth > innerWidth,
        formulasOutsideColumn: [...document.querySelectorAll('[data-tex]')].filter(el => {
          const box = el.getBoundingClientRect();
          const main = document.querySelector('main').getBoundingClientRect();
          return box.right > main.right + 1 || box.left < main.left - 1;
        }).length,
      })));
    }
    await page.setViewportSize({ width: 1365, height: 1000 });
    for (const [name, keyword] of [['probability', 'operatorname{Var}(X)'], ['ppo', 'operatorname{clip}'], ['attention', 'operatorname{Attention}']]) {
      const formula = page.locator('[data-tex]');
      const index = await page.locator('[data-tex]').evaluateAll((els, key) => els.findIndex(el => el.dataset.tex.includes(key)), keyword);
      assert(index >= 0, `Missing representative formula: ${name}`);
      await formula.nth(index).evaluate(el => el.scrollIntoView({ block: 'center', behavior: 'instant' }));
      await page.screenshot({ path: join(root, 'reports', `math-${name}.png`) });
    }
    await page.setViewportSize({ width: 390, height: 844 });
    await page.locator('[data-tex]').evaluateAll(els => els.find(el => el.dataset.tex.includes('operatorname{clip}')).scrollIntoView({ block: 'center', behavior: 'instant' }));
    await page.screenshot({ path: join(root, 'reports', 'math-mobile.png') });
    audit.errors = errors;
    audit.warnings = warnings;
    audit.failedRequests = failedRequests;
    fs.writeFileSync(join(root, 'reports', 'math_rendering_audit.json'), JSON.stringify(audit, null, 2) + '\n');
    console.log(JSON.stringify(audit, null, 2));
    assert(audit.formulas > 400);
    assert.equal(audit.symbolTable.rows, 9);
    assert.equal(audit.symbolTable.symbolCellsRendered, 9);
    assert(audit.byChapter[0].formulas > 0, 'Introduction must be included in the math audit');
    assert(audit.byChapter.at(-1).formulas > 0, 'Appendix must be included in the math audit');
    assert.equal(audit.rendered, audit.formulas);
    assert.equal(audit.failures, 0);
    assert.equal(audit.formulasInCode, 0);
    assert.equal(audit.residualMarkers, false);
    assert.deepEqual(audit.parseErrors, []);
    assert.deepEqual(errors, []);
    assert.deepEqual(warnings, []);
    assert.deepEqual(failedRequests, []);
    assert(audit.fontsLoaded > 0);
    assert(audit.layout.every(layout => !layout.pageOverflow && !layout.formulasOutsideColumn));
  } finally { await browser.close(); }
})().catch(error => { console.error(error); process.exitCode = 1; });
