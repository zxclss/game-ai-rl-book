# 第十一章代码验证记录

日期：2026-09-22。对象：[第十一章《手写算法与项目论证》](../chapters/11_手写算法与项目论证.md)。本记录只描述实际执行过的验证，不代表完整测试覆盖或生产可用性认证。

## 执行环境与方法

- Windows PowerShell；实际使用的解释器为 `C:\Users\zhaoxiucong\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe`，随后查询版本为 Python 3.12.14。
- 使用 UTF-8 读取章节 Markdown，正则提取所有 `python` 围栏代码，共 8 段，逐段调用 `ast.parse`，全部解析成功。
- 对前 6 段，即知识点 111–116 的标准库示例，在同一 Python 命名空间执行 `exec(compile(...))`，再执行下表中的断言。验证脚本经标准输入直接交给上述解释器，没有把手工重新录入的替代实现当成被测对象。
- 实际查询 `import torch`，得到 `ImportError`，检查日志记录 `torch_available: false`。**知识点 117–118 的 PyTorch 代码没有执行；仅做语法解析和正文手算审阅。**
- 最初用系统 `python` 命令的一次尝试退出码为 1、没有诊断输出，不计作有效验证；以上结果来自明确路径的解释器，退出码为 0。

实际验证输出中的结果字段：

```json
{"parsed_python_blocks": 8, "standard_library_sections_checked": "111-116", "checks": "passed", "torch_available": false}
```

## 已执行的代表性检查

| 知识点/函数 | 输入或构造 | 实际断言的预期结果 | 结果 |
|---|---|---|---|
| 111 `topk` | `[4,1,7,7,2,9]`, k=3 | `[9,7,7]`，保留重复 | 通过 |
| 111 `topk` | 空列表，k=3 | 空列表 | 通过 |
| 111 `topk` | `[1,2]`, k=0 | 空列表 | 通过 |
| 112 `longest_unique` | `abba` | 2，左边界不回退 | 通过 |
| 112 `three_sum` | `[-1,0,1,2,-1,-4]` | `[(-1,-1,2),(-1,0,1)]` | 通过 |
| 113 `lower_bound` | `[1,3,3,7]`, x=3 | 索引 1 | 通过 |
| 113 `lower_bound` | 同数组，x=8 | 索引 4，代表插入到末尾 | 通过 |
| 113 `reverse_list` | 三个节点依次相连 | 新头是原第三节点，其后是原第二节点；原第一节点 next 为 None | 通过 |
| 113 `lca` | 根节点有左右两个孩子，目标就是两孩子 | 返回根节点身份 | 通过 |
| 114 `astar` | 10×10 四邻接网格，起点 `(0,0)`，终点 `(2,0)`，进入 `(1,0)` 代价 5，其余为 1，曼哈顿启发式 | 最小路径代价 4 | 通过 |
| 114 `astar` | 起点与终点均为 `(2,0)` | `(0.0,[(2,0)])` | 通过 |
| 115 `lis_length` | `[10,9,2,5,3,7,101,18]` | 4 | 通过 |
| 115 `weighted_index` | 权重 `[1,0,3]`，`random.Random(10)`，重复 1000 次 | 从未选到零权重的索引 1 | 通过 |
| 115 `reservoir_one` | 单元素流 `[42]` | 42 | 通过 |
| 116 `cross_entropy` | logits `[1000,1001]`，标签 1 | 与 `0.3132616875` 相差小于 `1e-9` | 通过 |
| 116 `logistic_step` | x=2,y=1,w=0,b=0,学习率 0.1 | w 为 `[0.1]`，b 为 0.05 | 通过 |
| 116 `binary_ce_from_logit` | z=1000,y=1 | 绝对值小于 `1e-9` | 通过 |
| 116 `binary_ce_from_logit` | z=−1000,y=1 | 1000 | 通过 |

加权采样检查仅验证所选算例中的零权重排除，没有检验频率是否精确符合 1:3；蓄水池只执行了单元素情况，没有做均匀性统计试验。链表检查没有穷尽所有节点身份或环结构；A* 没有测试负权拒绝、不一致启发式重开或动态地图。上表不应被概括为“全部边界已通过”。

## 可复查的提取方式

以下是本次采用的代码提取与加载结构。重新执行会读取当时磁盘上的正文，因此正文后续若被编辑，属于一次新的验证；应重新记录结果。

```python
from pathlib import Path
import ast
import re

chapter = Path(r"D:\Documents\project\RL\book\chapters\11_手写算法与项目论证.md")
blocks = re.findall(r"```python\n(.*?)```", chapter.read_text(encoding="utf-8"), re.S)
for block in blocks:
    ast.parse(block)

namespace = {}
for block in blocks[:6]:
    exec(compile(block, "<book-example>", "exec"), namespace)

# 再对 namespace 内实际加载的函数执行上表所列输入/期望断言。
```

## 未执行的验证

没有安装或运行 PyTorch、Ray、RLlib，也没有执行 GPU、分布式训练、客户端部署或学习曲线实验。本次没有测量性能、胜率或训练收敛。知识点 117 的 GAE/PPO 与 118 的 Attention/DPO 数值仍属于公式手算例，不能把语法解析通过写成张量实现已经验证。
